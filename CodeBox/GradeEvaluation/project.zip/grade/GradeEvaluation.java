package kr.co.ezenac.project.grade;

public interface GradeEvaluation {
	String getGrade(int score);
}
